<?php

/**
 * Sidebar template
 *
 * @package CampusMarket
 */

if (! defined('ABSPATH')) {
    exit;
}

if (! is_active_sidebar('sidebar-1')) {
    return;
}
?>

<aside class="cm-sidebar" role="complementary">
    <?php dynamic_sidebar('sidebar-1'); ?>
</aside>